-- GUN (Give Up Now)
os.exit()
